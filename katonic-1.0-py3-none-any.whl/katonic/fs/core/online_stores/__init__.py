from katonic.fs.core.online_stores.redis import RedisOnlineStore
from katonic.fs.core.online_stores.sqlite import SqliteOnlineStore
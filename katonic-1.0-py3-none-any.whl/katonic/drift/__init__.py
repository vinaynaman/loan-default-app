
"""
Concept Drift Detection.
This module contains concept drift detection methods. The purpose of a drift detector is to raise
an alarm if the data distribution changes. A good drift detector method is the one that maximizes
the true positives while keeping the number of false positives to a minimum.
"""

from katonic.drift.adwin import ADWIN
from katonic.drift.ddm import DDM
from katonic.drift.eddm import EDDM
from katonic.drift.hddm_a import HDDM_A
from katonic.drift.hddm_w import HDDM_W
from katonic.drift.kswin import KSWIN
from katonic.drift.page_hinkley import PageHinkley
from katonic.drift.target_drift import PSI
from katonic.drift.target_drift import CSI

__all__ = ["ADWIN", "DDM", "EDDM", "PageHinkley", "HDDM_A", "HDDM_W", "KSWIN","PSI","CSI"]

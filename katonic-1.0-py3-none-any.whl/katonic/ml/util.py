
import os
from typing import List
import mlflow
import pandas as pd
import joblib

mlflow.set_tracking_uri(os.environ['MLFLOW_BASE_URL'])
client = mlflow.tracking.MlflowClient(os.environ['MLFLOW_BASE_URL'])

def set_exp(exp_name:str) -> None:
    '''
    Set given experiment as active experiment. If experiment does not exist, create an experiment with provided name.
    
    Args:
        exp_name (str): Case sensitive name of an experiment to be activated.
    '''
    return mlflow.set_experiment(exp_name)
    
def get_exp(exp_name:str) :
    '''
    Retrieve an experiment by experiment name from the backend store.

    Args:
        exp_name (str): The case senstive experiment name.
    '''
    result ={}
    mlflow.set_experiment(exp_name)
    exp_details = mlflow.get_experiment_by_name(exp_name)
    result['experiment_name'] = exp_details.name
    result['location']=exp_details.artifact_location
    result['experiment_id'] = exp_details.experiment_id
    result['experiment_stage'] = exp_details.lifecycle_stage
    result['tags'] = exp_details.tags
    
    return pd.DataFrame.from_dict(result,orient='index',columns=['parameters'])
    
#def get_exp_id(exp_name:str) :
#    '''
#    Retrieve an experiment id by experiment name from the backend store.

#    Args:
#       exp_name (str): The case senstive experiment name.
#    '''
#    mlflow.set_experiment(exp_name)
#    exp_details = mlflow.get_experiment_by_name(exp_name)
#    exp_id = exp_details.experiment_id
#    return exp_id
    
    
def staging(
            run_id:str,
            exp_name:str,
            model_name:str,
            stage:str
           ) -> None:
    '''
    Register the model in model registry and transit it to given stage.
    Staging, Production or Archived.

    Args:
        run_id (str): experiment id.
        exp_name (str): Case sensitive name of an experiment to be stagged.
        model_name (str): name of the model.
        stage (str): Each model version can be assigned one or many stages such as Staging, Production and archived.
    '''
    
    result = mlflow.register_model(
    "runs:/" + run_id,
    model_name
    )
    registered_model = pd.DataFrame(result, columns =['Attribute','Value']).set_index('Attribute')
    staging = client.transition_model_version_stage(
    name=registered_model.loc['name'][0],
    version=registered_model.loc['version'][0],
    stage=stage,
    )
    staged_model = pd.DataFrame(staging, columns =['Attribute','Value']).set_index('Attribute')
    print('Model information :')
    print(staged_model)
    return staged_model
    
def change_stage(
                 model_name:str,
                 ver_list:List[str],
                 stage:str
                ) -> None:
    '''
    Change stage of model. (Staging, Production or Archived).
    
    Args:
        model_name (str): name of the model.
        ver_list (List[str]): version list of the model.
        stage (str): Each model version can be assigned one or many stages such as Staging, Production and archived.
    '''
    
    for i in ver_list:
        staging = client.transition_model_version_stage(
        name=model_name,
        version=i,
        stage=stage,
        )
        print('{0} verison {1} archived'.format(model_name,i))

def model_versions(
                   model_name:str
                   )-> None:
    '''
    Return model versions if match with filter string.

    Args:
        model_name (str): name of the model.
    '''
    filter_string = "name='{}'".format(model_name)
    results = client.search_model_versions(filter_string)
    for res in results:
        print("name={}; run_id={}; version={}".format(res.name, res.run_id, res.version))
        
def log_data(
             prun_id:str,
             data_obj,
             location:str) ->None:
    '''
    Store joblib objects in model artifact.

    Args:
        prun_id (str): run_id of experiment.
        data_obj (Any): class object of any transformation function.
        location (str): location where the artifact will be logged.
    '''
    joblib.dump(data_obj,location)
    with mlflow.start_run(run_id = prun_id):
        mlflow.log_artifact(location,artifact_path='model/'+location+'/')
    print('data saved successfully....')
        
def search_runs(exp_id:str):
    '''
    Search runs and return dataframe of runs.

    Args:
        exp_id (List[str]): List of experiment IDs. None will default to the active experiment.
    '''
    df = mlflow.search_runs(experiment_ids=exp_id)
    df.columns = df.columns.str.replace('tags.mlflow.runName','run_name')
    exclude_cols = ['tags.mlflow.source.type','tags.mlflow.user', 'tags.mlflow.source.name']
    #column_names =  [x for x not in exclude_cols]
    df = df[df.columns.difference(exclude_cols)]
    return  df


def previous_version(
                    model_name:str
                    ):
    '''
    Return list of all previous versions.

    Args:
        model_name (str): name of the model.
    '''
    
    all_versions = []
    filter_string = "name='{}'".format(model_name)
    for x in client.search_model_versions(filter_string):
        all_versions.append(int(dict(x)['version']))
    all_versions.sort()
    previous_versions = list(map(lambda x : str(x),all_versions))[:-1]
    return previous_versions

def delete_model_version(
                        model_name:str,
                        ver_list:List[str]
                        ):
    '''
    Delete model versions.

    Args:
        model_name (str): name of the model.
        ver_list (List[str]): version list of the model.
    '''
    for version in ver_list:
        client.delete_model_version(name=model_name, version=version)
    
    return None

def delete_reg_model(
                    model_name:str
                    ):
    '''
    Delete registered model with all its version.

    Args:
        model_name (str): name of the model.
    '''
    client.delete_registered_model(name=model_name)
    
    return None

def delete_exp(
                    experiment_id:str
                    ):
    '''
    Delete registered model with all its version.

    Args:
        experiment_id (str): The experiment ID returned from ``set_exp``.
    '''
    client.delete_experiment(experiment_id)
    
    return None

def delete_run_by_id(run_id:str):
    '''
    Deletes a run with the given Run ID.

    Args:
        run_id (str): The unique run id to delete.
    '''
    client.delete_run(run_id)
    return None

def load_model(location):#(model_name,stage):
    '''
    Load a scikit-learn model from a local file or a run.

    Args:
        location: The location, in URI format, of the model, for example:

                      - ``/Users/me/path/to/local/model``
                      - ``relative/path/to/local/model``
                      - ``s3://my_bucket/path/to/model``
                      - ``runs:/<run_id>/run-relative/path/to/model``
                      - ``models:/<model_name>/<model_version>``
                      - ``models:/<model_name>/<stage>``

    Returns: 
        A scikit-learn model.
    '''
    return mlflow.sklearn.load_model(location)

# A decorator function to alter doc strings
def add_doc(value):
    def _doc(func):
        func.__doc__ = func.__doc__ + value
        return func
    return _doc


## This regression file acts as a central repository for various regression models that is being packaged under kaml module

import os
from typing import List
import mlflow
import mlflow.sklearn
from  mlflow.tracking import MlflowClient
from katonic.ml.client import MLClient
import pandas as pd
import numpy as np
import sklearn
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
from typing import List, Tuple, Any, Union, Optional, Dict
import warnings
from IPython.utils import io
import logging
import traceback

#mlflow.sklearn.autolog(log_models=True)
logging.basicConfig(level=logging.WARN)

logger = logging.getLogger(__name__)
mlflow.set_tracking_uri(os.environ['MLFLOW_BASE_URL'])
client = mlflow.tracking.MlflowClient(os.environ['MLFLOW_BASE_URL'])

warnings.filterwarnings("ignore")

def input_validation(data_train:pd.DataFrame,
                     data_test:pd.DataFrame,
                     experiment_name:str
                     ):
    '''
    Args:
        data_train (pandas.DataFrame): Shape (n_samples, n_features), where n_samples is the number of samples and 
            n_features is the number of features for train dataset.

        data_test (pandas.DataFrame): Shape (n_samples, n_features), where n_samples is the number of samples and 
            n_features is the number of features for test dataset.

        experiment_name (str): Name of the experiment for logging.
    '''
        
    if not (isinstance(data_train, pd.DataFrame) or isinstance(data_train,np.ndarray)):
        raise TypeError(f"data_train passed must be of type pandas.DataFrame or numpy.ndarray")
    if data_train.shape[0] == 0:
        raise ValueError(f"data_train passed must be a positive dataframe")
    if not (isinstance(data_test, pd.DataFrame) or isinstance(data_test,np.ndarray)):
        raise TypeError(f"data_test passed must be of type pandas.DataFrame or numpy.ndarray")
    if data_test.shape[0] == 0:
        raise ValueError(f"data_test passed must be a positive dataframe")
    if not isinstance(experiment_name,str):
        raise ValueError(f"experiment name should be string")     

class TimeSeries(MLClient):
    
    def __init__(self, 
                 data_train:pd.DataFrame,
                 data_test:pd.DataFrame,
                 experiment_name:str):
        '''
        Args:
            data_train (pandas.DataFrame): Shape (n_samples, n_features), where n_samples is the number of samples and 
                n_features is the number of features for train dataset.

            data_test (pandas.DataFrame): Shape (n_samples, n_features), where n_samples is the number of samples and 
                n_features is the number of features for test dataset.

            experiment_name (str): Name of the experiment for logging.
        '''
        
        logger.info(f"Validation Start")
        input_validation(data_train,data_test,experiment_name)
        logger.info(f"Validation End")
        
        super().__init__(experiment_name)
        
        self.data_train = data_train
        self.data_test = data_test
        
        logger.info(f"Time Series successfully instantiated")

    def __str__(self):
        return "Time Series models for experiment: Experiment Name is %s, Experiment ID is %s" % (self.name, self.id)
        
    
    def eval_metrics(self,actual:Union[pd.Series,pd.DataFrame,np.ndarray], pred:Union[pd.Series,pd.DataFrame,np.ndarray])->Tuple:
        '''
        Calculates various evaluation parameters like mse,rmse,mae rmsle for time series problem.

        Args:
            actual (pandas.Series or pandas.DataFrame, or numpy array): actual testing data
            pred (pandas.Series or pandas.DataFrame, or numpy array): predicted testing data

        Returns:
            (
                mse: mean square error,
                rmse: root mean square error,
                rmsle: root mean square log error,
                mae: mean absolute error,
                r2: r-2 score,
            )
        '''


        logger.info(f"Calculating evaluation paramaters")
        try:
            mse = mean_squared_error(actual, pred)
        except:
            logger.error(f"mean_squared_error calcuation raised an exception:")
            logger.error(traceback.format_exc())
        try:
            rmse = np.sqrt(mse)
        except:
            logger.error(f"root_mean_squared_error calcuation raised an exception:")
            logger.error(traceback.format_exc())
        try:
            rmsle = np.log(rmse)
        except:
            logger.error(f"root_mean_squared_log_error calcuation raised an exception:")
            logger.error(traceback.format_exc())
        try:
            mae = mean_absolute_error(actual, pred)
        except:
            logger.error(f"mean_absolute_error calcuation raised an exception:")
            logger.error(traceback.format_exc())
        try:
            r2 = r2_score(actual, pred)
        except:
            logger.error(f"r2 score calcuation raised an exception:")
            logger.error(traceback.format_exc())
 
        return mse,rmse,rmsle,mae,r2 



    def model_fit_log(self, model:Any,run_name:str)->None:
        '''
        Performs the model fitting and model prediction task. It calls the evaluation metrics function and logs the required metrics for the model.

        Args:
            model (Object): time-series model object
            run_name (str): It register a model under ``run_name`` if one with the given name does not exist.
        '''
        logger.info(f"Training the model")
        try:
            model_fit = model.fit()
        except:
            logger.error(f"Fitting the model {run_name} raised an exception:")
            logger.error(traceback.format_exc())

        logger.info(f"Performing the prediction")

        try:
            y_pred=model_fit.predict(self.data_test)
        except:
            logger.error(f" Prediction process raised an exception:")
            logger.error(traceback.format_exc())

        (mse,rmse,rmsle,mae, r2) = self.eval_metrics(self.data_test,y_pred)

        metrics = {"MSE":mse,"RMSE":rmse,"RMSLE":rmsle,"MAE":mae,"R2":r2}

        logger.info(f"logged params: {metrics.keys()}")
        try:
            mlflow.log_metrics(metrics)
        except:
            logger.warning("Couldn't log metrics. Exception:")
            logger.warning(traceback.format_exc())
        logger.info(f"logging model {run_name}")
        try:
            mlflow.sklearn.log_model(model,run_name)
        except:
            logger.warning("Couldn't log model. Exception:")
            logger.warning(traceback.format_exc())    

    ## Autoregression ##   
    def AutoReg(self,**kwargs)->None:
        '''
        This module performs experiments for Autoregression model.

        Args:
            **kwargs: List of parameters that will be passed to define the model.
            Refer: https://scikit-learn.org/stable/modules/generated/sklearn.linear_model.LinearRegression.html 
            for list of parameters that can be passed to model.
        '''
        logger.info("-----------Auto Regression----------------") 

        from statsmodels.tsa.ar_model import AutoReg    

        run_name = self.name+"_"+self.id+"_"+"auto_reg"
        try:
            with mlflow.start_run(run_name=run_name):
                model = AutoReg(self.data_train**kwargs)
                self.model_fit_log(model,run_name)
        except:
            logger.warning("Couldn't perform runs on model. Exception:")
            logger.warning(traceback.format_exc())
            
    ## Autoregression ##   
    def AutoReg(self,**kwargs)->None:
        '''
        This module performs experiments for Autoregression model.

        Args:
            **kwargs: List of parameters that will be passed to define the model.
            Refer: https://scikit-learn.org/stable/modules/generated/sklearn.linear_model.LinearRegression.html 
            for list of parameters that can be passed to model.
        '''
        logger.info("-----------Auto Regression----------------") 

        from statsmodels.tsa.ar_model import AutoReg    

        run_name = self.name+"_"+self.id+"_"+"auto_reg"
        try:
            with mlflow.start_run(run_name=run_name):
                model = AutoReg(self.data_train**kwargs)
                self.model_fit_log(model,run_name)
        except:
            logger.warning("Couldn't perform runs on model. Exception:")
            logger.warning(traceback.format_exc())

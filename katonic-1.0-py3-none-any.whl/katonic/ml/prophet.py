import os
from typing import List
import mlflow
import mlflow.sklearn
from  mlflow.tracking import MlflowClient

from fbprophet import Prophet
from sklearn.metrics import mean_squared_error, r2_score, mean_absolute_error
import numpy as np
import mlflow.pyfunc

mlflow.set_tracking_uri(os.environ['MLFLOW_BASE_URL'])
client = mlflow.tracking.MlflowClient(os.environ['MLFLOW_BASE_URL'])

def run_model(train, test, model_name):   
    '''
    

    Args:
        train (pandas.DataFrame): Shape (n_samples, n_features), where n_samples is the number of samples and 
            n_features is the number of features for train dataset.

        test (pandas.DataFrame): Shape (n_samples, n_features), where n_samples is the number of samples and 
            n_features is the number of features for test dataset.

        model_name (str): Name of new run.
    '''
    with mlflow.start_run(run_name=model_name):
        model=Prophet()
        model.fit(train)

        test_pred = model.predict(test[['ds']])

        mlflow.log_metric("r2_score", r2_score(test['y'],test_pred['yhat']))
        mlflow.log_metric("mean_absolute_error", mean_absolute_error(test['y'],test_pred['yhat']))

        mlflow.log_metric("root_mean_squared_error", np.sqrt(mean_squared_error(test['y'],test_pred['yhat'])))

        mlflow.sklearn.log_model(model, model_name)
        
        return model, test_pred
        
def register_model(run_id, model_name):
    '''
    Create a new model version in model registry for the model files specified by model_uri. Note that this method assumes the model registry backend URI is the same as that of the tracking backend.
    
    Args:
        model_name (str): Name of the registered model under which to create a new model version. If a
            registered model with the given name does not exist, it will be created automatically..
    
    '''
    return mlflow.register_model("runs:/" + run_id,model_name)


def load_model(location):#(model_name,stage):
    '''
    Load a scikit-learn model from a local file or a run.

    Args:
        location: The location, in URI format, of the model, for example:

                      - ``/Users/me/path/to/local/model``
                      - ``relative/path/to/local/model``
                      - ``s3://my_bucket/path/to/model``
                      - ``runs:/<run_id>/run-relative/path/to/model``
                      - ``models:/<model_name>/<model_version>``
                      - ``models:/<model_name>/<stage>``

    Returns: 
        A scikit-learn model.
    '''
    return mlflow.sklearn.load_model(location)